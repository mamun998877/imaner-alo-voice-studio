package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.SheetState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.AudioFileHelper
import com.example.data.local.entity.VoiceRecordEntity
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldLight
import com.example.ui.theme.IslamicGreenPrimary
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExportShareBottomSheet(
    record: VoiceRecordEntity,
    sheetState: SheetState,
    onDismissRequest: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val audioFile = File(record.audioFilePath)

    ModalBottomSheet(
        onDismissRequest = onDismissRequest,
        sheetState = sheetState,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        containerColor = MaterialTheme.colorScheme.surface,
        modifier = modifier.testTag("export_share_bottom_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
        ) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = IslamicGreenPrimary.copy(alpha = 0.15f),
                    modifier = Modifier.size(42.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = null,
                            tint = IslamicGreenPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
                Column {
                    Text(
                        text = "ভয়েসওভার এক্সপোর্ট ও শেয়ার",
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = record.title,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Option 1: Share to Social & Messaging Apps
            ExportOptionCard(
                icon = Icons.AutoMirrored.Filled.Send,
                title = "সামাজিক মাধ্যম ও মেসেজিং অ্যাপে শেয়ার",
                subtitle = "WhatsApp, Telegram, Messenger, Facebook, Drive ইত্যাদিতে অডিও ফাইল পাঠান",
                iconBgColor = IslamicGreenPrimary,
                onClick = {
                    AudioFileHelper.shareAudioFile(
                        context = context,
                        file = audioFile,
                        title = record.title,
                        script = record.script
                    )
                    onDismissRequest()
                },
                testTag = "share_to_apps_button"
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Option 2: Export to Public Music / Downloads (CapCut / Video Editors)
            ExportOptionCard(
                icon = Icons.Default.Folder,
                title = "ডিভাইসের মিউজিক ফোল্ডারে এক্সপোর্ট",
                subtitle = "CapCut, VN, Kinemaster ও ভিডিও এডিটরে ব্যবহারের জন্য সেভ করুন (Music/ImanerAlo/)",
                iconBgColor = GoldAccent,
                onClick = {
                    AudioFileHelper.exportAudioToPublicStorage(
                        context = context,
                        file = audioFile,
                        customTitle = record.title
                    )
                    onDismissRequest()
                },
                testTag = "export_to_storage_button"
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Option 3: Copy Script
            ExportOptionCard(
                icon = Icons.Default.ContentCopy,
                title = "বাংলা স্ক্রিপ্ট কপি করুন",
                subtitle = "ক্যাপশন বা ভিডিও ডেসক্রিপশনের জন্য স্ক্রিপ্ট ক্লিপবোর্ডে কপি করুন",
                iconBgColor = MaterialTheme.colorScheme.secondary,
                onClick = {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    val clip = ClipData.newPlainText("Bengali Script", record.script)
                    clipboard.setPrimaryClip(clip)
                    Toast.makeText(context, "স্ক্রিপ্ট ক্লিপবোর্ডে কপি করা হয়েছে", Toast.LENGTH_SHORT).show()
                    onDismissRequest()
                },
                testTag = "copy_script_button"
            )

            Spacer(modifier = Modifier.height(28.dp))
        }
    }
}

@Composable
fun ExportOptionCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    iconBgColor: Color,
    onClick: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier
) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ),
        modifier = modifier
            .fillMaxWidth()
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = iconBgColor,
                modifier = Modifier.size(44.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 15.sp
                )
            }
        }
    }
}
