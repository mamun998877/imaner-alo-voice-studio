package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Islamic Emerald Greens
val IslamicGreenPrimary = Color(0xFF0F6848)
val IslamicGreenSecondary = Color(0xFF198754)
val IslamicGreenLight = Color(0xFF2EAA7B)
val IslamicGreenDark = Color(0xFF083C28)

// Deep Navy & Dark Blue
val DeepNavyDark = Color(0xFF0A192F)
val DeepNavySurface = Color(0xFF112240)
val DeepNavyLight = Color(0xFF233554)

// Islamic Gold Accents
val GoldAccent = Color(0xFFD4AF37)
val GoldLight = Color(0xFFFFDF79)
val GoldDark = Color(0xFF9A7B1C)
val GoldContainerLight = Color(0xFFFFF3D4)

// Neutrals & Surfaces
val CreamWhite = Color(0xFFFBFBF8)
val SoftSurfaceLight = Color(0xFFF2F7F4)
val SurfaceDark = Color(0xFF0D1B16)
val BackgroundDark = Color(0xFF070F0C)

val OnSurfaceLight = Color(0xFF18221D)
val OnSurfaceDark = Color(0xFFE5EDE9)
val TextMuted = Color(0xFF6C7C75)
val CardBorderLight = Color(0xFFDCE8E2)
val CardBorderDark = Color(0xFF1E382E)
