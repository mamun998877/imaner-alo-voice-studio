package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = IslamicGreenLight,
    onPrimary = DeepNavyDark,
    primaryContainer = IslamicGreenDark,
    onPrimaryContainer = GoldLight,
    secondary = GoldAccent,
    onSecondary = DeepNavyDark,
    secondaryContainer = DeepNavyLight,
    onSecondaryContainer = GoldLight,
    tertiary = GoldLight,
    onTertiary = DeepNavyDark,
    background = BackgroundDark,
    onBackground = OnSurfaceDark,
    surface = SurfaceDark,
    onSurface = OnSurfaceDark,
    surfaceVariant = DeepNavySurface,
    onSurfaceVariant = Color(0xFFC7D7D0),
    outline = CardBorderDark
)

private val LightColorScheme = lightColorScheme(
    primary = IslamicGreenPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD4EFE3),
    onPrimaryContainer = IslamicGreenDark,
    secondary = DeepNavyDark,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD9E2EC),
    onSecondaryContainer = DeepNavyDark,
    tertiary = GoldDark,
    onTertiary = Color.White,
    tertiaryContainer = GoldContainerLight,
    onTertiaryContainer = GoldDark,
    background = CreamWhite,
    onBackground = OnSurfaceLight,
    surface = Color.White,
    onSurface = OnSurfaceLight,
    surfaceVariant = SoftSurfaceLight,
    onSurfaceVariant = TextMuted,
    outline = CardBorderLight
)

@Composable
fun ImanerAloTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

// Keep backwards-compatible alias
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    ImanerAloTheme(darkTheme = darkTheme, content = content)
}
