package com.example.audio

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

object AudioFileHelper {

    /**
     * Decodes Base64 audio payload and writes to a playable audio file (WAV/MP3).
     * If PCM raw data is received, automatically prepends a canonical 44-byte RIFF WAV header.
     */
    fun saveBase64AudioToFile(
        context: Context,
        base64Data: String,
        mimeType: String,
        prefix: String = "voiceover"
    ): File {
        val decodedBytes = Base64.decode(base64Data, Base64.DEFAULT)
        val audioDir = File(context.filesDir, "audio").apply { if (!exists()) mkdirs() }
        
        val isPcm = mimeType.contains("pcm", ignoreCase = true) || 
                    mimeType.contains("raw", ignoreCase = true) || 
                    mimeType.contains("l16", ignoreCase = true) ||
                    (!mimeType.contains("mp3", ignoreCase = true) && 
                     !mimeType.contains("ogg", ignoreCase = true) && 
                     !mimeType.contains("aac", ignoreCase = true) && 
                     !isWavFormat(decodedBytes))

        val extension = if (mimeType.contains("mp3", ignoreCase = true)) ".mp3" else ".wav"
        val fileName = "${prefix}_${System.currentTimeMillis()}$extension"
        val file = File(audioDir, fileName)

        FileOutputStream(file).use { fos ->
            if (isPcm) {
                val sampleRate = extractSampleRate(mimeType)
                val wavHeader = createWavHeader(
                    pcmDataLength = decodedBytes.size,
                    sampleRate = sampleRate,
                    channels = 1,
                    bitsPerSample = 16
                )
                fos.write(wavHeader)
            }
            fos.write(decodedBytes)
        }

        return file
    }

    private fun isWavFormat(bytes: ByteArray): Boolean {
        if (bytes.size < 12) return false
        val riff = String(bytes, 0, 4)
        val wave = String(bytes, 8, 4)
        return riff == "RIFF" && wave == "WAVE"
    }

    private fun extractSampleRate(mimeType: String): Int {
        val rateRegex = Regex("rate=(\\d+)")
        val match = rateRegex.find(mimeType)
        return match?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 24000
    }

    private fun createWavHeader(
        pcmDataLength: Int,
        sampleRate: Int,
        channels: Int,
        bitsPerSample: Int
    ): ByteArray {
        val byteRate = sampleRate * channels * bitsPerSample / 8
        val blockAlign = channels * bitsPerSample / 8
        val totalDataLen = pcmDataLength + 36

        val header = ByteArray(44)
        val buffer = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)

        // RIFF header
        buffer.put("RIFF".toByteArray(Charsets.US_ASCII))
        buffer.putInt(totalDataLen)
        buffer.put("WAVE".toByteArray(Charsets.US_ASCII))

        // 'fmt ' subchunk
        buffer.put("fmt ".toByteArray(Charsets.US_ASCII))
        buffer.putInt(16) // Subchunk1Size for PCM
        buffer.putShort(1.toShort()) // AudioFormat (1 = PCM)
        buffer.putShort(channels.toShort())
        buffer.putInt(sampleRate)
        buffer.putInt(byteRate)
        buffer.putShort(blockAlign.toShort())
        buffer.putShort(bitsPerSample.toShort())

        // 'data' subchunk
        buffer.put("data".toByteArray(Charsets.US_ASCII))
        buffer.putInt(pcmDataLength)

        return header
    }

    /**
     * Creates and launches the standard Android Sharesheet to send the audio file
     * to installed messaging apps (WhatsApp, Telegram, Messenger), social media apps,
     * video editors, Drive, Bluetooth, or Mail.
     */
    fun shareAudioFile(
        context: Context,
        file: File,
        title: String,
        script: String = ""
    ) {
        if (!file.exists()) {
            Toast.makeText(context, "অডিও ফাইল পাওয়া যায়নি", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val mimeType = if (file.name.endsWith(".mp3", ignoreCase = true)) "audio/mp3" else "audio/wav"

            val shareText = if (script.isNotBlank()) {
                "🔊 $title\n\n📝 স্ক্রিপ্ট:\n$script\n\n✨ ঈমানের আলো ভয়েস স্টুডিও (Imaner Alo Voice Studio)"
            } else {
                "🔊 $title - ঈমানের আলো ভয়েস স্টুডিও"
            }

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, title)
                putExtra(Intent.EXTRA_TEXT, shareText)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            val chooser = Intent.createChooser(shareIntent, "ভয়েসওভার শেয়ার বা এক্সপোর্ট করুন").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            // Grant read permission explicitly to any resolving package
            val resInfoList = context.packageManager.queryIntentActivities(chooser, 0)
            for (resolveInfo in resInfoList) {
                val packageName = resolveInfo.activityInfo.packageName
                context.grantUriPermission(packageName, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            context.startActivity(chooser)
        } catch (e: Exception) {
            Toast.makeText(context, "শেয়ার করতে সমস্যা: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }

    /**
     * Exports the audio file into the public Downloads or Audio directory
     * so external video editors (CapCut, Kinemaster, VN, Premiere), music players,
     * and file explorers can directly access it.
     */
    fun exportAudioToPublicStorage(
        context: Context,
        file: File,
        customTitle: String
    ): Boolean {
        if (!file.exists()) {
            Toast.makeText(context, "অডিও ফাইল পাওয়া যায়নি", Toast.LENGTH_SHORT).show()
            return false
        }

        val sanitizedTitle = customTitle.replace(Regex("[^a-zA-Z0-9\\u0980-\\u09FF_\\- ]"), "_").trim()
        val displayName = "${sanitizedTitle}_${System.currentTimeMillis()}${if (file.name.endsWith(".mp3")) ".mp3" else ".wav"}"
        val mimeType = if (file.name.endsWith(".mp3")) "audio/mpeg" else "audio/wav"

        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Audio.Media.DISPLAY_NAME, displayName)
                    put(MediaStore.Audio.Media.MIME_TYPE, mimeType)
                    put(MediaStore.Audio.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MUSIC}/ImanerAlo/")
                    put(MediaStore.Audio.Media.IS_PENDING, 1)
                }

                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)

                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { outputStream ->
                        FileInputStream(file).use { inputStream ->
                            inputStream.copyTo(outputStream)
                        }
                    }

                    values.clear()
                    values.put(MediaStore.Audio.Media.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)

                    Toast.makeText(context, "অডিও মিউজিক ফোল্ডারে সংরক্ষিত হয়েছে:\nMusic/ImanerAlo/$displayName", Toast.LENGTH_LONG).show()
                    true
                } else {
                    false
                }
            } else {
                @Suppress("DEPRECATION")
                val publicDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC), "ImanerAlo")
                if (!publicDir.exists()) publicDir.mkdirs()
                val destFile = File(publicDir, displayName)
                file.copyTo(destFile, overwrite = true)
                Toast.makeText(context, "অডিও সংরক্ষিত হয়েছে: ${destFile.absolutePath}", Toast.LENGTH_LONG).show()
                true
            }
        } catch (e: Exception) {
            Toast.makeText(context, "এক্সপোর্ট করতে সমস্যা: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            false
        }
    }
}
