package com.example.audio

import android.content.Context
import android.media.MediaPlayer
import android.net.Uri
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

data class PlayerState(
    val isPlaying: Boolean = false,
    val currentPosition: Int = 0,
    val duration: Int = 0,
    val isLoaded: Boolean = false,
    val currentFilePath: String? = null,
    val errorMessage: String? = null
)

class AudioPlayerManager(private val context: Context) {
    private var mediaPlayer: MediaPlayer? = null
    private val scope = CoroutineScope(Dispatchers.Main)
    private var progressJob: Job? = null

    private val _playerState = MutableStateFlow(PlayerState())
    val playerState: StateFlow<PlayerState> = _playerState.asStateFlow()

    fun loadAndPlay(filePath: String, autoPlay: Boolean = true) {
        val file = File(filePath)
        if (!file.exists()) {
            _playerState.value = _playerState.value.copy(
                errorMessage = "অডিও ফাইল পাওয়া যায়নি"
            )
            return
        }

        try {
            stop()
            mediaPlayer = MediaPlayer().apply {
                setDataSource(context, Uri.fromFile(file))
                prepare()
                val totalDuration = duration
                _playerState.value = PlayerState(
                    isPlaying = false,
                    currentPosition = 0,
                    duration = totalDuration,
                    isLoaded = true,
                    currentFilePath = filePath,
                    errorMessage = null
                )

                setOnCompletionListener {
                    _playerState.value = _playerState.value.copy(
                        isPlaying = false,
                        currentPosition = totalDuration
                    )
                    stopProgressTracking()
                }

                if (autoPlay) {
                    start()
                    _playerState.value = _playerState.value.copy(isPlaying = true)
                    startProgressTracking()
                }
            }
        } catch (e: Exception) {
            _playerState.value = _playerState.value.copy(
                errorMessage = "অডিও চালু করতে সমস্যা: ${e.localizedMessage}"
            )
        }
    }

    fun togglePlayPause() {
        val player = mediaPlayer ?: return
        if (player.isPlaying) {
            player.pause()
            _playerState.value = _playerState.value.copy(isPlaying = false)
            stopProgressTracking()
        } else {
            // If finished, reset to start
            if (player.currentPosition >= player.duration - 200) {
                player.seekTo(0)
            }
            player.start()
            _playerState.value = _playerState.value.copy(isPlaying = true)
            startProgressTracking()
        }
    }

    fun seekTo(positionMs: Int) {
        mediaPlayer?.let { player ->
            player.seekTo(positionMs)
            _playerState.value = _playerState.value.copy(currentPosition = positionMs)
        }
    }

    fun stop() {
        stopProgressTracking()
        mediaPlayer?.apply {
            if (isPlaying) stop()
            reset()
            release()
        }
        mediaPlayer = null
        _playerState.value = PlayerState()
    }

    private fun startProgressTracking() {
        stopProgressTracking()
        progressJob = scope.launch {
            while (isActive) {
                mediaPlayer?.let { player ->
                    if (player.isPlaying) {
                        _playerState.value = _playerState.value.copy(
                            currentPosition = player.currentPosition,
                            duration = player.duration
                        )
                    }
                }
                delay(100)
            }
        }
    }

    private fun stopProgressTracking() {
        progressJob?.cancel()
        progressJob = null
    }

    fun release() {
        stop()
    }
}
