package com.example.viewmodel

import android.app.Application
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import com.example.BuildConfig
import com.example.data.local.PreferencesManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SettingsViewModel(application: Application) : AndroidViewModel(application) {
    val preferencesManager = PreferencesManager(application)

    val customApiKey: StateFlow<String> = preferencesManager.customApiKey
    val defaultVoice: StateFlow<String> = preferencesManager.defaultVoice
    val defaultStyle: StateFlow<String> = preferencesManager.defaultStyle
    val defaultSpeed: StateFlow<String> = preferencesManager.defaultSpeed
    val themeMode: StateFlow<String> = preferencesManager.themeMode
    val selectedModel: StateFlow<String> = preferencesManager.selectedModel

    private val _apiKeyInput = MutableStateFlow(preferencesManager.customApiKey.value)
    val apiKeyInput: StateFlow<String> = _apiKeyInput.asStateFlow()

    fun updateApiKeyInput(key: String) {
        _apiKeyInput.value = key
    }

    fun saveApiKey() {
        preferencesManager.setCustomApiKey(_apiKeyInput.value)
        Toast.makeText(getApplication(), "API কী সংরক্ষিত হয়েছে", Toast.LENGTH_SHORT).show()
    }

    fun clearApiKey() {
        _apiKeyInput.value = ""
        preferencesManager.setCustomApiKey("")
        Toast.makeText(getApplication(), "ব্যক্তিগত API কী মুছে ফেলা হয়েছে", Toast.LENGTH_SHORT).show()
    }

    fun setDefaultVoice(voice: String) {
        preferencesManager.setDefaultVoice(voice)
    }

    fun setDefaultStyle(style: String) {
        preferencesManager.setDefaultStyle(style)
    }

    fun setDefaultSpeed(speed: String) {
        preferencesManager.setDefaultSpeed(speed)
    }

    fun setThemeMode(mode: String) {
        preferencesManager.setThemeMode(mode)
    }

    fun setSelectedModel(model: String) {
        preferencesManager.setSelectedModel(model)
    }

    fun isUsingBuildConfigKey(): Boolean {
        val custom = customApiKey.value.trim()
        val buildKey = try { BuildConfig.GEMINI_API_KEY } catch (e: Exception) { "" }
        return custom.isEmpty() && buildKey.isNotEmpty() && buildKey != "MY_GEMINI_API_KEY"
    }
}
