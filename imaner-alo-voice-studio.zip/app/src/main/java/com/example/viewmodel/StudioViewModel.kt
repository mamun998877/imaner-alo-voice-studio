package com.example.viewmodel

import android.app.Application
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioFileHelper
import com.example.audio.AudioPlayerManager
import com.example.audio.PlayerState
import com.example.data.IslamicTemplate
import com.example.data.local.AppDatabase
import com.example.data.local.PreferencesManager
import com.example.data.local.entity.VoiceRecordEntity
import com.example.data.remote.GeminiApiService
import com.example.data.repository.VoiceRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

sealed interface GenerationState {
    object Idle : GenerationState
    data class Generating(val message: String = "বাংলা ভয়েসওভার তৈরি করা হচ্ছে…") : GenerationState
    data class Success(val record: VoiceRecordEntity) : GenerationState
    data class Error(val message: String) : GenerationState
}

data class VoiceOption(
    val id: String,
    val name: String,
    val description: String,
    val gender: String
)

val AVAILABLE_VOICES = listOf(
    VoiceOption("Charon", "Charon (গম্ভীর পুরুষ)", "গভীর, শান্ত ও ইসলামিক নসিহতের জন্য সেরা", "পুরুষ"),
    VoiceOption("Fenrir", "Fenrir (বজ্রকণ্ঠ পুরুষ)", "ওজনদার, তেজস্বী ও প্রভাবশালী কণ্ঠ", "পুরুষ"),
    VoiceOption("Puck", "Puck (সাবলীল পুরুষ)", "সহজ, স্বাভাবিক ও গল্প বলার উপযোগী", "পুরুষ"),
    VoiceOption("Kore", "Kore (শান্ত নারী)", "স্পষ্ট, পরিশীলিত ও আন্তরিক ভয়েস", "নারী"),
    VoiceOption("Aoede", "Aoede (কোমল নারী)", "মৃদু, আবেগঘন ও হৃদয়স্পর্শী", "নারী"),
    VoiceOption("Leda", "Leda (স্নিগ্ধ নারী)", "শান্ত, নির্মল ও ধার্মিক আবহ", "নারী"),
    VoiceOption("Zephyr", "Zephyr (তরুণ কণ্ঠ)", "ঝরঝরে ও প্রাণবন্ত আধুনিক ভয়েস", "পুরুষ"),
    VoiceOption("Orus", "Orus (অভিজ্ঞ কণ্ঠ)", "প্রজ্ঞাময় ও শ্রদ্ধাশীল গুরুগম্ভীর সুর", "পুরুষ")
)

val VOICE_STYLES = listOf(
    "Islamic Emotional",
    "Calm",
    "Deep",
    "Soft",
    "Inspirational",
    "Storytelling"
)

val SPEAKING_SPEEDS = listOf(
    "Slow",
    "Normal",
    "Fast"
)

class StudioViewModel(application: Application) : AndroidViewModel(application) {

    private val preferencesManager = PreferencesManager(application)
    private val database = AppDatabase.getInstance(application)
    private val apiService = GeminiApiService.create()
    val repository = VoiceRepository(application, apiService, database.voiceRecordDao(), preferencesManager)
    val playerManager = AudioPlayerManager(application)

    private val _script = MutableStateFlow("")
    val script: StateFlow<String> = _script.asStateFlow()

    private val _selectedVoice = MutableStateFlow(preferencesManager.defaultVoice.value)
    val selectedVoice: StateFlow<String> = _selectedVoice.asStateFlow()

    private val _selectedStyle = MutableStateFlow(preferencesManager.defaultStyle.value)
    val selectedStyle: StateFlow<String> = _selectedStyle.asStateFlow()

    private val _selectedSpeed = MutableStateFlow(preferencesManager.defaultSpeed.value)
    val selectedSpeed: StateFlow<String> = _selectedSpeed.asStateFlow()

    private val _generationState = MutableStateFlow<GenerationState>(GenerationState.Idle)
    val generationState: StateFlow<GenerationState> = _generationState.asStateFlow()

    private val _currentRecord = MutableStateFlow<VoiceRecordEntity?>(null)
    val currentRecord: StateFlow<VoiceRecordEntity?> = _currentRecord.asStateFlow()

    val playerState: StateFlow<PlayerState> = playerManager.playerState

    fun updateScript(newScript: String) {
        _script.value = newScript
    }

    fun selectVoice(voiceId: String) {
        _selectedVoice.value = voiceId
    }

    fun selectStyle(style: String) {
        _selectedStyle.value = style
    }

    fun selectSpeed(speed: String) {
        _selectedSpeed.value = speed
    }

    fun applyIslamicEmotionalPreset() {
        _selectedVoice.value = "Charon"
        _selectedStyle.value = "Islamic Emotional"
        _selectedSpeed.value = "Slow"
        Toast.makeText(getApplication(), "ইসলামিক ইমোশনাল প্রিসেট সক্রিয় করা হয়েছে", Toast.LENGTH_SHORT).show()
    }

    fun applyTemplate(template: IslamicTemplate) {
        _script.value = template.script
        _selectedVoice.value = template.recommendedVoice
        _selectedStyle.value = template.recommendedStyle
        _selectedSpeed.value = template.recommendedSpeed
    }

    fun clearScript() {
        _script.value = ""
    }

    fun generateVoiceover() {
        val currentScript = _script.value.trim()
        if (currentScript.isEmpty()) {
            _generationState.value = GenerationState.Error("অনুগ্রহ করে কিছু বাংলা স্ক্রিপ্ট লিখুন বা পেস্ট করুন।")
            return
        }

        viewModelScope.launch {
            _generationState.value = GenerationState.Generating("Gemini TTS এর মাধ্যমে ভয়েসওভার তৈরি হচ্ছে…")
            playerManager.stop()

            val result = repository.generateIslamicVoiceover(
                script = currentScript,
                voiceName = _selectedVoice.value,
                style = _selectedStyle.value,
                speed = _selectedSpeed.value
            )

            result.onSuccess { record ->
                _currentRecord.value = record
                _generationState.value = GenerationState.Success(record)
                playerManager.loadAndPlay(record.audioFilePath, autoPlay = true)
            }.onFailure { error ->
                _generationState.value = GenerationState.Error(
                    error.message ?: "ভয়েস তৈরি করতে ব্যর্থ হয়েছে। অনুগ্রহ করে ইন্টারনেট সংযোগ ও API কী চেক করুন।"
                )
            }
        }
    }

    fun togglePlayback() {
        playerManager.togglePlayPause()
    }

    fun seekAudio(positionMs: Int) {
        playerManager.seekTo(positionMs)
    }

    fun shareCurrentAudio() {
        val record = _currentRecord.value ?: return
        val file = File(record.audioFilePath)
        if (file.exists()) {
            AudioFileHelper.shareAudioFile(getApplication(), file, record.title)
        } else {
            Toast.makeText(getApplication(), "অডিও ফাইল পাওয়া যায়নি", Toast.LENGTH_SHORT).show()
        }
    }

    fun saveAudioNotification() {
        Toast.makeText(getApplication(), "অডিও সফলভাবে ডিভাইসে সংরক্ষিত আছে!", Toast.LENGTH_LONG).show()
    }

    fun dismissError() {
        if (_generationState.value is GenerationState.Error) {
            _generationState.value = GenerationState.Idle
        }
    }

    override fun onCleared() {
        super.onCleared()
        playerManager.release()
    }
}
