package com.example.viewmodel

import android.app.Application
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioFileHelper
import com.example.audio.AudioPlayerManager
import com.example.audio.PlayerState
import com.example.data.local.AppDatabase
import com.example.data.local.PreferencesManager
import com.example.data.local.entity.VoiceRecordEntity
import com.example.data.remote.GeminiApiService
import com.example.data.repository.VoiceRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

class HistoryViewModel(application: Application) : AndroidViewModel(application) {

    private val preferencesManager = PreferencesManager(application)
    private val database = AppDatabase.getInstance(application)
    private val apiService = GeminiApiService.create()
    val repository = VoiceRepository(application, apiService, database.voiceRecordDao(), preferencesManager)
    val playerManager = AudioPlayerManager(application)

    val historyList: StateFlow<List<VoiceRecordEntity>> = repository.allHistory
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val playerState: StateFlow<PlayerState> = playerManager.playerState

    fun playRecord(record: VoiceRecordEntity) {
        val currentPath = playerState.value.currentFilePath
        if (currentPath == record.audioFilePath) {
            playerManager.togglePlayPause()
        } else {
            playerManager.loadAndPlay(record.audioFilePath, autoPlay = true)
        }
    }

    fun deleteRecord(record: VoiceRecordEntity) {
        viewModelScope.launch {
            if (playerState.value.currentFilePath == record.audioFilePath) {
                playerManager.stop()
            }
            repository.deleteRecord(record)
            Toast.makeText(getApplication(), "রেকর্ড ডিলিট করা হয়েছে", Toast.LENGTH_SHORT).show()
        }
    }

    fun shareRecord(record: VoiceRecordEntity) {
        val file = File(record.audioFilePath)
        if (file.exists()) {
            AudioFileHelper.shareAudioFile(getApplication(), file, record.title)
        } else {
            Toast.makeText(getApplication(), "অডিও ফাইল পাওয়া যায়নি", Toast.LENGTH_SHORT).show()
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            playerManager.stop()
            repository.clearHistory()
            Toast.makeText(getApplication(), "সকল ইতিহাস মুছে ফেলা হয়েছে", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCleared() {
        super.onCleared()
        playerManager.release()
    }
}
