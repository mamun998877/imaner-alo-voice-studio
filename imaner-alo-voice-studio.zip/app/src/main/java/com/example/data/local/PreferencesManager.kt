package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class PreferencesManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("imaner_alo_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_CUSTOM_API_KEY = "custom_gemini_api_key"
        private const val KEY_DEFAULT_VOICE = "default_voice"
        private const val KEY_DEFAULT_STYLE = "default_style"
        private const val KEY_DEFAULT_SPEED = "default_speed"
        private const val KEY_THEME_MODE = "theme_mode" // "SYSTEM", "LIGHT", "DARK"
        private const val KEY_SELECTED_MODEL = "selected_gemini_model"
    }

    private val _customApiKey = MutableStateFlow(prefs.getString(KEY_CUSTOM_API_KEY, "") ?: "")
    val customApiKey: StateFlow<String> = _customApiKey.asStateFlow()

    private val _defaultVoice = MutableStateFlow(prefs.getString(KEY_DEFAULT_VOICE, "Charon") ?: "Charon")
    val defaultVoice: StateFlow<String> = _defaultVoice.asStateFlow()

    private val _defaultStyle = MutableStateFlow(prefs.getString(KEY_DEFAULT_STYLE, "Islamic Emotional") ?: "Islamic Emotional")
    val defaultStyle: StateFlow<String> = _defaultStyle.asStateFlow()

    private val _defaultSpeed = MutableStateFlow(prefs.getString(KEY_DEFAULT_SPEED, "Normal") ?: "Normal")
    val defaultSpeed: StateFlow<String> = _defaultSpeed.asStateFlow()

    private val _themeMode = MutableStateFlow(prefs.getString(KEY_THEME_MODE, "SYSTEM") ?: "SYSTEM")
    val themeMode: StateFlow<String> = _themeMode.asStateFlow()

    private val _selectedModel = MutableStateFlow(prefs.getString(KEY_SELECTED_MODEL, "gemini-2.5-flash-preview-tts") ?: "gemini-2.5-flash-preview-tts")
    val selectedModel: StateFlow<String> = _selectedModel.asStateFlow()

    fun setCustomApiKey(key: String) {
        prefs.edit().putString(KEY_CUSTOM_API_KEY, key.trim()).apply()
        _customApiKey.value = key.trim()
    }

    fun setDefaultVoice(voice: String) {
        prefs.edit().putString(KEY_DEFAULT_VOICE, voice).apply()
        _defaultVoice.value = voice
    }

    fun setDefaultStyle(style: String) {
        prefs.edit().putString(KEY_DEFAULT_STYLE, style).apply()
        _defaultStyle.value = style
    }

    fun setDefaultSpeed(speed: String) {
        prefs.edit().putString(KEY_DEFAULT_SPEED, speed).apply()
        _defaultSpeed.value = speed
    }

    fun setThemeMode(mode: String) {
        prefs.edit().putString(KEY_THEME_MODE, mode).apply()
        _themeMode.value = mode
    }

    fun setSelectedModel(model: String) {
        prefs.edit().putString(KEY_SELECTED_MODEL, model).apply()
        _selectedModel.value = model
    }
}
