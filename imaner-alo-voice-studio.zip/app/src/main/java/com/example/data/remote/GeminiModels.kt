package com.example.data.remote

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class GeminiTTSRequest(
    val contents: List<TTSContent>,
    val generationConfig: TTSGenerationConfig? = null,
    val systemInstruction: TTSContent? = null
)

@JsonClass(generateAdapter = true)
data class TTSContent(
    val parts: List<TTSPart>
)

@JsonClass(generateAdapter = true)
data class TTSPart(
    val text: String? = null,
    val inlineData: TTSInlineData? = null
)

@JsonClass(generateAdapter = true)
data class TTSInlineData(
    val mimeType: String,
    val data: String
)

@JsonClass(generateAdapter = true)
data class TTSGenerationConfig(
    val responseModalities: List<String>? = listOf("AUDIO"),
    val speechConfig: TTSSpeechConfig? = null,
    val temperature: Float? = null
)

@JsonClass(generateAdapter = true)
data class TTSSpeechConfig(
    val voiceConfig: TTSVoiceConfig
)

@JsonClass(generateAdapter = true)
data class TTSVoiceConfig(
    val prebuiltVoiceConfig: TTSPrebuiltVoiceConfig
)

@JsonClass(generateAdapter = true)
data class TTSPrebuiltVoiceConfig(
    val voiceName: String
)

@JsonClass(generateAdapter = true)
data class GeminiTTSResponse(
    val candidates: List<TTSCandidate>? = null,
    val error: GeminiErrorDetails? = null
)

@JsonClass(generateAdapter = true)
data class TTSCandidate(
    val content: TTSContent? = null,
    val finishReason: String? = null
)

@JsonClass(generateAdapter = true)
data class GeminiErrorDetails(
    val code: Int? = null,
    val message: String? = null,
    val status: String? = null
)
