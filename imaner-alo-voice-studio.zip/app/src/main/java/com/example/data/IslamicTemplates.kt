package com.example.data

data class IslamicTemplate(
    val id: String,
    val category: String,
    val title: String,
    val script: String,
    val recommendedVoice: String = "Charon",
    val recommendedStyle: String = "Islamic Emotional",
    val recommendedSpeed: String = "Normal"
)

object IslamicTemplatesProvider {
    val templates = listOf(
        IslamicTemplate(
            id = "reminder_sabar",
            category = "সবর ও সান্ত্বনা",
            title = "কষ্টের পরেই রয়েছে সুখ (সবর)",
            script = "হে প্রিয় ভাই ও বোন, জীবনে যখন দুঃখ-কষ্ট আর একাকিত্ব তোমাকে ঘিরে ধরবে, তখন হতাশ হয়ো না। মনে রেখো, পবিত্র কুরআনে মহান আল্লাহ তা'আলা বলেছেন— 'নিশ্চয়ই কষ্টের সাথেই রয়েছে স্বস্তি।' তোমার প্রতিটি অশ্রুফোঁটা আল্লাহর কাছে অত্যন্ত মূল্যবান। ধৈর্য ধারণ করো, আল্লাহর ফয়সালার উপর ভরসা রাখো। নিশ্চয়ই আল্লাহ ধৈর্যশীলদের ভালোবাসেন।",
            recommendedVoice = "Charon",
            recommendedStyle = "Islamic Emotional",
            recommendedSpeed = "Slow"
        ),
        IslamicTemplate(
            id = "reminder_tawbah",
            category = "তাওবা ও ক্ষমা",
            title = "আল্লাহর রহমত থেকে নিরাশ হয়ো না",
            script = "তোমার পাপ যতই বেশি হোক না কেন, আল্লাহর রহমত তার চেয়েও কোটি গুণ বিশাল। এক মুহূর্তের জন্য সিজদায় লুটিয়ে পড়ে বলো— 'হে আমার রব, আমাকে ক্ষমা করে দিন।' বান্দা যখন অনুতপ্ত হৃদয়ে আল্লাহর দরবারে ফিরে আসে, আল্লাহ তখন আসমান ও জমিনের সব পাপ মাফ করে তাকে আপন করে নেন। সুবহানাল্লাহ।",
            recommendedVoice = "Charon",
            recommendedStyle = "Islamic Emotional",
            recommendedSpeed = "Slow"
        ),
        IslamicTemplate(
            id = "reminder_fajr",
            category = "নামাজ ও আমল",
            title = "ফজরের নামাজের মধুর ডাক",
            script = "যখন সমগ্র পৃথিবী গভীর ঘুমে মগ্ন, তখন মুমিনের হৃদয় জেগে ওঠে তার প্রতিপালকের ডাকে। 'আস-সালাতু খাইরুম মিনান নাওম'— নামাজের চেয়ে ঘুম উত্তম নয়। ফজরের দুই রাকাত সুন্নাত সারা দুনিয়া এবং এর ভেতরের সবকিছুর চেয়ে বেশি মূল্যবান। উঠুন, অজু করুন এবং মহান আল্লাহর সান্নিধ্য লাভ করুন।",
            recommendedVoice = "Fenrir",
            recommendedStyle = "Inspirational",
            recommendedSpeed = "Normal"
        ),
        IslamicTemplate(
            id = "reminder_parents",
            category = "পিতা-মাতা",
            title = "মা-বাবার প্রতি ভালোবাসা ও শ্রদ্ধা",
            script = "মা-বাবার চেয়ে নিঃস্বার্থ আর কেউ হতে পারে না। তোমার একটু হাসির জন্য যিনি রাত জেগেছেন, তিনি তোমার মা। আর যিনি নিজের সব ইচ্ছা বিসর্জন দিয়ে তোমাকে মানুষ করেছেন, তিনি তোমার বাবা। তাদের সাথে কখনো উচ্চস্বরে কথা বলো না। বলো— 'হে আমার প্রতিপালক, তাদের প্রতি দয়া করুন, যেমন তারা শৈশবে আমাকে লালন-পালন করেছিলেন।'",
            recommendedVoice = "Aoede",
            recommendedStyle = "Soft",
            recommendedSpeed = "Slow"
        ),
        IslamicTemplate(
            id = "reminder_jannah",
            category = "জান্নাত ও আখেরাত",
            title = "জান্নাতের অপার শান্তি ও নেয়ামত",
            script = "এই দুনিয়ার জীবন ক্ষণস্থায়ী, অনন্ত জীবন তো অপেক্ষা করছে আখিরাতে। যেখানে কোনো দুঃখ নেই, কোনো কষ্ট নেই, নেই কোনো ভয়। সেখানে প্রবাহমান নহর, সুবাসিত বাতাস আর সবচেয়ে বড় নেয়ামত— স্বচক্ষে মহান আল্লাহ রাব্বুল আলামিনের নূর দর্শন করা। আল্লাহ আমাদের সবাইকে জান্নাতুল ফিরদাউস নসিব করুন। আমিন।",
            recommendedVoice = "Charon",
            recommendedStyle = "Calm",
            recommendedSpeed = "Normal"
        ),
        IslamicTemplate(
            id = "reminder_story_prophet",
            category = "নবীজির জীবনী",
            title = "বিশ্বনবী হযরত মুহাম্মদ (সা.)-এর মহান চরিত্র",
            script = "রাসূলুল্লাহ সাল্লাল্লাহু আলাইহি ওয়াসাল্লাম ছিলেন সমগ্র মানবজাতির জন্য রহমতস্বরূপ। যিনি কখনো শত্রুর জন্যও বদদোয়া করেননি, বরং তাদের হেদায়েতের জন্য কাতর প্রার্থনা করেছেন। যার প্রতিটি পদক্ষেপে ছিল সততা, ক্ষমা এবং অপরিসীম দয়া। আসুন, আমরা প্রিয় নবীজির সুন্নাহকে আমাদের জীবনের প্রতিটি ক্ষেত্রে ধারণ করি।",
            recommendedVoice = "Puck",
            recommendedStyle = "Storytelling",
            recommendedSpeed = "Normal"
        )
    )
}
