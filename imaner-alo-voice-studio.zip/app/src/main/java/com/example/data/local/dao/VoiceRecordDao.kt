package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.entity.VoiceRecordEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface VoiceRecordDao {
    @Query("SELECT * FROM voice_records ORDER BY createdAt DESC")
    fun getAllRecords(): Flow<List<VoiceRecordEntity>>

    @Query("SELECT * FROM voice_records WHERE id = :id")
    suspend fun getRecordById(id: Long): VoiceRecordEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecord(record: VoiceRecordEntity): Long

    @Delete
    suspend fun deleteRecord(record: VoiceRecordEntity)

    @Query("DELETE FROM voice_records WHERE id = :id")
    suspend fun deleteRecordById(id: Long)

    @Query("DELETE FROM voice_records")
    suspend fun clearAll()
}
