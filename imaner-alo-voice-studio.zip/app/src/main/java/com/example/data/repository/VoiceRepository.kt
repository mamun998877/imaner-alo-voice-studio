package com.example.data.repository

import android.content.Context
import com.example.BuildConfig
import com.example.audio.AudioFileHelper
import com.example.data.local.PreferencesManager
import com.example.data.local.dao.VoiceRecordDao
import com.example.data.local.entity.VoiceRecordEntity
import com.example.data.remote.GeminiApiService
import com.example.data.remote.GeminiTTSRequest
import com.example.data.remote.TTSContent
import com.example.data.remote.TTSGenerationConfig
import com.example.data.remote.TTSPart
import com.example.data.remote.TTSPrebuiltVoiceConfig
import com.example.data.remote.TTSSpeechConfig
import com.example.data.remote.TTSVoiceConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File

class VoiceRepository(
    private val context: Context,
    private val apiService: GeminiApiService,
    private val dao: VoiceRecordDao,
    private val preferencesManager: PreferencesManager
) {
    val allHistory: Flow<List<VoiceRecordEntity>> = dao.getAllRecords()

    fun getEffectiveApiKey(): String {
        val customKey = preferencesManager.customApiKey.value.trim()
        if (customKey.isNotEmpty()) {
            return customKey
        }
        return try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }
    }

    suspend fun generateIslamicVoiceover(
        script: String,
        voiceName: String,
        style: String,
        speed: String
    ): Result<VoiceRecordEntity> = withContext(Dispatchers.IO) {
        val apiKey = getEffectiveApiKey()
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext Result.failure(
                IllegalStateException("Gemini API Key পাওয়া যায়নি। অনুগ্রহ করে সেটিংস পেজে আপনার এপিআই কী যুক্ত করুন।")
            )
        }

        val model = preferencesManager.selectedModel.value

        // Construct high-fidelity Bengali Islamic TTS prompt
        val directionPrompt = buildVoiceDirectionPrompt(style, speed)
        val combinedPrompt = """
            $directionPrompt
            
            Strictly read and pronounce the following Bengali script accurately with natural Bengali phonetics, reverent Islamic cadence, and emotional pauses:
            
            $script
        """.trimIndent()

        val request = GeminiTTSRequest(
            contents = listOf(
                TTSContent(
                    parts = listOf(TTSPart(text = combinedPrompt))
                )
            ),
            systemInstruction = TTSContent(
                parts = listOf(
                    TTSPart(
                        text = "You are a master Bengali Islamic audio narrator. Your pronunciation of Bengali words, Islamic Arabic loanwords (e.g. আল্লাহ, রাসূলুল্লাহ, সুবহানাল্লাহ, জান্নাত, জাহান্নাম), and spiritual phrasing is reverent, deep, emotionally rich, and completely natural without robotic cadence."
                    )
                )
            ),
            generationConfig = TTSGenerationConfig(
                responseModalities = listOf("AUDIO"),
                speechConfig = TTSSpeechConfig(
                    voiceConfig = TTSVoiceConfig(
                        prebuiltVoiceConfig = TTSPrebuiltVoiceConfig(voiceName = voiceName)
                    )
                ),
                temperature = 0.6f
            )
        )

        try {
            val response = apiService.generateSpeech(
                model = model,
                apiKey = apiKey,
                request = request
            )

            val candidate = response.candidates?.firstOrNull()
            val audioPart = candidate?.content?.parts?.firstOrNull { it.inlineData != null }
            val inlineData = audioPart?.inlineData

            if (inlineData == null || inlineData.data.isEmpty()) {
                val errorMsg = response.error?.message 
                    ?: "Gemini থেকে অডিও রেসপন্স পাওয়া যায়নি। মডেল বা এপিআই কী যাচাই করুন।"
                return@withContext Result.failure(RuntimeException(errorMsg))
            }

            // Save audio to file
            val title = extractTitleFromScript(script)
            val audioFile = AudioFileHelper.saveBase64AudioToFile(
                context = context,
                base64Data = inlineData.data,
                mimeType = inlineData.mimeType,
                prefix = "imaner_alo"
            )

            // Calculate rough duration (file size estimation or default)
            val durationEstimate = estimateAudioDuration(audioFile, inlineData.mimeType)

            val record = VoiceRecordEntity(
                title = title,
                script = script,
                voiceName = voiceName,
                style = style,
                speed = speed,
                audioFilePath = audioFile.absolutePath,
                durationMillis = durationEstimate,
                charCount = script.length,
                createdAt = System.currentTimeMillis()
            )

            val recordId = dao.insertRecord(record)
            val savedRecord = record.copy(id = recordId)

            Result.success(savedRecord)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun buildVoiceDirectionPrompt(style: String, speed: String): String {
        val speedInstruction = when (speed.lowercase()) {
            "slow", "ধীর" -> "Pace: Slow, deliberate, and clearly articulated with extended pauses at sentence breaks."
            "fast", "দ্রুত" -> "Pace: Fluid, fluent, and slightly brisk while maintaining dignified Islamic clarity."
            else -> "Pace: Natural, balanced, steady Islamic narrative tempo."
        }

        val styleInstruction = when (style) {
            "Islamic Emotional", "ইসলামিক ইমোশনাল" -> """
                Speak in a warm, deep, emotional and calm Bengali male narration style.
                Use natural pauses between sentences.
                Do not sound robotic.
                Deliver the narration respectfully and peacefully, suitable for an Islamic reminder video.
            """.trimIndent()

            "Calm", "শান্ত ও প্রশান্ত" -> """
                Speak in a tranquil, serene, gentle, and deeply peaceful Bengali tone.
                Soft breathing cadence and meditative tranquility.
            """.trimIndent()

            "Deep", "গম্ভীর ও প্রজ্ঞাপূর্ণ" -> """
                Speak in a deep, authoritative, resonant, and solemn Bengali tone with profound gravity and presence.
            """.trimIndent()

            "Soft", "কোমল ও হৃদয়স্পর্শী" -> """
                Speak in a gentle, warm, compassionate, and tender Bengali voice, comforting and heartfelt.
            """.trimIndent()

            "Inspirational", "অনুপ্রেরণামূলক" -> """
                Speak in an inspiring, uplifting, motivational, and faith-strengthening Bengali tone full of hope and conviction.
            """.trimIndent()

            "Storytelling", "কাহিনি ও ঐতিহাসিক" -> """
                Speak in an engaging, narrative Bengali storytelling voice, evocative of historical Islamic accounts and biographical chronicles.
            """.trimIndent()

            else -> """
                Speak in a respectful, warm, and natural Bengali voice suitable for Islamic educational and spiritual media.
            """.trimIndent()
        }

        return "$styleInstruction\n$speedInstruction"
    }

    private fun extractTitleFromScript(script: String): String {
        val firstLine = script.lines().firstOrNull { it.isNotBlank() }?.trim() ?: "ইসলামিক ভয়েসওভার"
        return if (firstLine.length > 40) {
            firstLine.take(37) + "..."
        } else {
            firstLine
        }
    }

    private fun estimateAudioDuration(file: File, mimeType: String): Long {
        return try {
            val bytes = file.length()
            if (mimeType.contains("mp3")) {
                // ~16KB/sec for 128kbps mp3
                (bytes / 16)
            } else {
                // 16-bit 24kHz mono PCM = 48,000 bytes/sec
                (bytes * 1000 / 48000)
            }
        } catch (e: Exception) {
            0L
        }
    }

    suspend fun deleteRecord(record: VoiceRecordEntity) {
        try {
            val file = File(record.audioFilePath)
            if (file.exists()) {
                file.delete()
            }
        } catch (_: Exception) {}
        dao.deleteRecord(record)
    }

    suspend fun clearHistory() {
        dao.clearAll()
    }
}
