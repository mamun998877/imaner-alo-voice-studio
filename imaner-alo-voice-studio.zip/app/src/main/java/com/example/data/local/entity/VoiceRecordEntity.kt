package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "voice_records")
data class VoiceRecordEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val script: String,
    val voiceName: String,
    val style: String,
    val speed: String,
    val audioFilePath: String,
    val durationMillis: Long = 0,
    val charCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)
